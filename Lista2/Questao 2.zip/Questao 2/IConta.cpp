#include "IConta.h"

void IConta::sacar (double valor){}
void IConta::depositar (double valor){}